// 1
package framework;

public interface Item {
	public void use();
	
}

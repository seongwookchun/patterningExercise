
public class Shape implements cloneable{
						// implement""s"" s�� �ٴ´�.
	
}

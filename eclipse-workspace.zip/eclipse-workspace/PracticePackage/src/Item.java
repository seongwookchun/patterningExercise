
public interface Item {
	public void use();

}

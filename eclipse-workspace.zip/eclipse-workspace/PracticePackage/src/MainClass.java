
public class MainClass {

	public static void main(String[] args) {
		System.out.println("hhelo");
		HpPotion hpuse;
		
		hpuse = new HpPotion();
		hpuse.use();
	}

}

package pratice;

public class AbsGameConnection {

}
